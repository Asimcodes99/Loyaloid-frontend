$(document).ready(function(){ 
  
 
   $(".nav-link").click(function() {
      // remove classes from all
      $(".nav-link").removeClass("active");
      // add class to the one we clicked
      $(this).addClass("active");
   });  
 
//  home page modal email

//   $(".email-modal-btn").click(function() {
//       $('#email-modal').modal('show');
//   });  
  
	 }); 

















// $('.claim-now-btn-small').on('click', function(){
//          $('.claim-now-btn').css('background-position' , 'left bottom'); 
//       $('.claim-now-btn').css('color' , 'rgb(84 108 220)'); 

//      }); 
//    setTimeout(function(){
      
//       $(".logo-area").css("visibility","visible")
//       .addClass('animated  fadeInDown');},
//        500);
      
//       setTimeout(function(){
//       $(".tagline-area-1").css("visibility","visible")
//       .addClass('animated fadeIn');}, 1500);

//       setTimeout(function(){
//       $(".body-cloud-img-1").css("visibility","visible")
//       .addClass('animated fadeIn');}, 2500);

//       setTimeout(function(){
//       $(".username-1").css("visibility","visible")
//       .addClass('animated fadeIn');}, 3500);

//       setTimeout(function(){
//       $(".usermail-1").css("visibility","visible")
//       .addClass('animated fadeIn');}, 4500);

//       setTimeout(function(){
//       $(".area-text").css("visibility","visible")
//       .addClass('animated fadeIn');}, 5500);

//       setTimeout(function(){
//       $(".informa-below").css("visibility","visible")
//       .addClass('animated fadeIn');}, 6500);
      
//       setTimeout(function(){
//       $(".main-box-class").css("visibility","visible")
//       .addClass('animated fadeIn');}, 7500);

//       setTimeout(function(){
//       $(".storage-box").css("visibility","visible")
//       .addClass('animated fadeIn');}, 8500);

 

//    $('.storage-box').on('click', function(){  

//       $(".last-section-found").removeClass("d-none"); 
//        $(".last-section-found").addClass("animated fadeIn");
// setTimeout(function(){
//       $(".tagline-area-2").removeClass("d-none"); 

//       $(".new-plan-div").removeClass("d-none"); 
//       $(".new-plan-div").addClass("animated fadeIn");


//       $(".last-btn-section").removeClass("d-none"); 
//       $(".confirm-section").removeClass("d-none"); 
//       $(".confirm-btn").removeClass("d-none"); 
//       $(".box-upgrage").addClass("d-none"); 
//       $(".Storage-limit-reached").addClass("d-none");
//       $(".Storage-limit-reached").addClass("d-none");
//       $(".username-2").css("visibility" , "visible");
//       $(".usermail-2").css("visibility" , "visible");
//        }, 1500);
//    setTimeout(function(){ 
//        $(".last-btn-section").removeClass("v-none");
//        $(".last-btn-section").removeClass("animated fadeIn"); 
//        $(".confirm-section").removeClass("v-none");
//        $(".confirm-section").removeClass("animated fadeIn"); 
      
//    }, 2500);

//    setTimeout(function(){ 
//        $(".confirm-btn").removeClass("v-none");
//        $(".confirm-btn").removeClass("animated fadeIn"); 
      
//    }, 3500);

         
   
//  });
//  });